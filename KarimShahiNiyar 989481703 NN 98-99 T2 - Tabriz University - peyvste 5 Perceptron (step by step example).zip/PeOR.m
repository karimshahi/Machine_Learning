% Perceptron OR
close all;
clear;
clc;

x1=[1 1 0 0];
x2=[1 0 1 0];
t=[1 1 1 -1]; % For OR
% t=[1 -1 -1 -1]; % For AND
bias=[1 1 1 1];
teta=0.2;
alpha=1;
w1=0;
w2=0;
b=0;
dw1=alpha.*x1.*t;
dw2=alpha.*x2.*t;
db=alpha.*t;
counter=1;
finished=0;
np=size(x1,2);

while(finished==0)
    disp(['   Itteration ' num2str(counter) ' :']);
    disp('    X1    X2  Bias   Yin     Y     T   DW1   DW2    DB    W1    W2     B');
    disp('------------------------------------------------------------------------');
    cdw1=zeros(1,np);
    cdw2=zeros(1,np);
    cdb=zeros(1,np);
    
    for i=1:np
        yin=w1*x1(i)+w2*x2(i)+b;
       
        if yin>teta
            y=1;
        elseif abs(yin)<=teta
            y=0;
        else
            y=-1;
        end

        if y~=t(i)
            w1=w1+dw1(i);
            w2=w2+dw2(i);
            b=b+db(i);
            
            cdw1(i)=dw1(i);
            cdw2(i)=dw2(i);
            cdb(i)=db(i);
        else
            
            cdw1(i)=0;
            cdw2(i)=0;
            cdb(i)=0;
        end
        
        disp([x1(i) x2(i) bias(i) yin y t(i) cdw1(i) cdw2(i) cdb(i) w1 w2 b]);
    end
    disp('========================================================================');

    finished=1;
    for i=1:np
       if(cdw1(i)~=0)
           finished =0;
       end
    end
    for i=1:np
       if(cdw2(i)~=0)
           finished =0;
       end
    end
    for i=1:np
       if(cdb(i)~=0)
           finished =0;
       end
    end
    
    counter=counter+1;

end

disp(['Finished Succesfully in ' num2str(counter-1) ' Steps']);
