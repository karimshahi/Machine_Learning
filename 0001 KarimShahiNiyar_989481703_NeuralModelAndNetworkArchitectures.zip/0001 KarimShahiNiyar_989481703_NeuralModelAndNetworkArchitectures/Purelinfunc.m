function n=Purelinfunc(x)
n=purelin(x);
end