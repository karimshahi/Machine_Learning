function n=MatrixN(x)
n=-x:0.1:x;
end