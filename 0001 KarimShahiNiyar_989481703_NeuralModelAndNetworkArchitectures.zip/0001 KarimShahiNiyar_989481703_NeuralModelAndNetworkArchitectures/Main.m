clear;
close all;

n=MatrixN(5);%create matrix

figure('name','karim shahi niyar 989481703 tabriz university ');

hold on
ax1 = subplot(3,3,1); %  subplot
NMC=Comfunc(n); %Neural Model and Network Architecture == NM
plot(ax1,n,NMC,'Color',[0.1,0.5,0.8]);
title('compet');

ax2 = subplot(3,3,2); %  subplot
% figure;
NMP=Poslinfunc(n);
plot(ax2,n,NMP,'Color',[0.1,0.2,0.3]);
title('poslin');

ax3 = subplot(3,3,3); %  subplot
% figure;
NMT=Tansigfunc(n);
plot(ax3,n,NMT,'Color',[0.2,0.3,0.5]);
title('tansig');

ax4 = subplot(3,3,4); %  subplot
% figure;
NML=Logsigfunc(n);
plot(ax4,n,NML,'Color',[0.5,0.3,0.2]);
title('logsig');


ax5 = subplot(3,3,5); %  subplot
% figure;
NMSs=Satlinsfunc(n);
plot(ax5,n,NMSs,'Color',[0.8,0.5,0.3]);
title('satlins');
    

ax6 = subplot(3,3,6); %  subplot
% figure;
NMS=Satlinfunc(n);
plot(ax6,n,NMS,'Color',[0.5,0.3,0.8]);
title('satlin');
    
ax7 = subplot(3,3,7); %  subplot
% figure;
NMPu=Purelinfunc(n);
plot(ax7,n,NMPu,'Color',[0.5,0.1,0.3]);
title('purelin');
    
ax8 = subplot(3,3,8); %  subplot
% figure;
NMHls=Hardlimsfunc(n);
plot(ax8,n,NMHls,'Color',[0.8,0.1,0.2]);
title('hardlims');
    

ax9 = subplot(3,3,9); %  subplot
% figure;
NMHl=Hardlimfunc(n);
plot(ax9,n,NMHl,'Color',[0.8,0.5,0.2]);
title('hardlim');

    
hold off


