function a=Comfunc(x)
a=compet(x);
end
