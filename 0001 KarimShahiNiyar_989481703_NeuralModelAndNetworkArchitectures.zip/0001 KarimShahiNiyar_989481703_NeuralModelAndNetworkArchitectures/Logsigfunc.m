function n=Logsigfunc(x)
n=logsig(x);
end