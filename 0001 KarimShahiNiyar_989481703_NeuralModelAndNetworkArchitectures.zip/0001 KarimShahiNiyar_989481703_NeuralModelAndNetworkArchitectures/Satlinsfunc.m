function n=Satlinsfunc(x)
n=satlins(x);
end