function n=Hardlimsfunc(x)
n=hardlims(x);
end