function n=Satlinfunc(x)
n=satlin(x);
end