function n=Poslinfunc(x)
n=poslin(x);
end