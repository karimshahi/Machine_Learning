function n=Tansigfunc(x)
n=tansig(x);
end