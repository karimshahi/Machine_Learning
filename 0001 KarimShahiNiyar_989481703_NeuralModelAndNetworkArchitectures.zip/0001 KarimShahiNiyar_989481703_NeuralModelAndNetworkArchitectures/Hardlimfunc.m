function n=Hardlimfunc(x)
n=hardlim(x);
end